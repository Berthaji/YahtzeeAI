from collections import namedtuple, deque
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from yahtzee_api import YahtzeeGame, ACTION_INDEX_LIMIT
from DQN_yahtzee import DQN
from train_alt import get_valid_actions

CHECKPOINT_NAME = 'checkpoint_yahtzee_alt.pth'
device = torch.device("cpu") 


def play_alt(agent, game, n_games):
    """
    Esegui N partite di Yahtzee usando l'agente DQN addestrato.
    Calcola e stampa i punteggi di ogni partita e la media finale.

    Parameters:
    - agent: l'agente DQN utilizzato per scegliere le azioni.
    - game: l'oggetto del gioco Yahtzee.
    - n_games: il numero di partite da giocare.

    Returns:
    - scores: una lista contenente i punteggi di ogni partita.
    """
    scores = []  # Lista per memorizzare i punteggi ottenuti

    for game_index in range(n_games):
        game.newGame()  # Nuova partita
        state = np.array(game.getDiceValues() + [game.rollLeft()] + game.completed_rows, dtype=np.float32)
        total_score = 0.0

        # Esegui il gioco finché non è terminato
        while not game.hasFinished():

            # Determina le azioni valide basate sullo stato del gioco
            valid_actions = get_valid_actions(game)

            if not valid_actions:
                print("Nessuna azione valida disponibile. Episodio terminato.")
                break

            # Scegli l'azione tramite l'agente (con epsilon = 0 per sfruttare la politica appresa)
            action = agent.getAction(state, epsilon=0.0, valid_actions=valid_actions)
            game.chooseAction(action)
            reward = float(game.getLastReward())
            next_state = np.array(game.getDiceValues() + [game.rollLeft()] + game.completed_rows, dtype=np.float32)

            # Passa allo stato successivo
            state = next_state
            total_score += reward

            if game.hasFinished():
                break

        # Memorizza il punteggio della partita
        scores.append(total_score)
        print(f"Partita {game_index + 1}/{n_games} - Punteggio: {total_score}")

    # Calcola e stampa la media dei punteggi
    average_score = np.mean(scores)
    print(f"\nPunteggio medio su {n_games} partite: {average_score}")

    return scores


if __name__ == "__main__":
    n_states = 19  # 5 dadi, 1 tiri rimasti, 13 righe completate
    n_actions = 45  # 15 azioni di rilancio, 3 azioni di selezione riga
    n_games = 500

    # Creazione dell'agente e caricamento del modello
    agent = DQN(
            n_states=n_states, 
            n_actions=n_actions,
            batch_size=128, 
            learning_rate=1e-3,
            gamma=0.9, 
            learn_step=5, 
            mem_size=int(1e6), 
            tau=1e-3
    )
    agent.net_eval.load_state_dict(torch.load(CHECKPOINT_NAME, map_location=device, weights_only=True))
    agent.net_eval.eval()

    game = YahtzeeGame()
    play_alt(agent, game, n_games)
