# YahtzeeAI
DQN agent trained to play Yahtzee to obtain the maximum score (target score fixed at 200 points as the average of the last 100 episodes)
