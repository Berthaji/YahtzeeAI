import numpy as np
import torch
from tqdm import trange
from yahtzee_api import ACTION_INDEX_LIMIT

CHECKPOINT_NAME = 'checkpoint_yahtzee_alt.pth'
RECENT_EPISODES = 100  # Numero di episodi di riferimento per l'average score
MIN_EPISODES_FOR_STOP = 100 


def get_valid_actions(game):
    # Controllo per il caso in cui non ci siano rilanci disponibili
    if game.rollLeft() == 0:
        valid_rows = [i + ACTION_INDEX_LIMIT for i, row in enumerate(game.scorecard.keys()) if game.scorecard[row] is None]
        
        # Se non ci sono righe valide, restituisci None
        return valid_rows if valid_rows else None
    
    # Se ci sono rilanci disponibili, restituisci un intervallo per le azioni di rilancio
    return list(range(0, ACTION_INDEX_LIMIT))


def train_alt(agent, game, n_episodes, max_steps, eps_start, eps_end, eps_decay, target_score, store_checkpoint):
    """
    Esegui il ciclo di addestramento per il DQN con la gestione delle azioni valide.
    Aggiorna epsilon per esplorazione ridotta.
    """
    score_history = []
    epsilon = eps_start

    # Barra di avanzamento per tenere traccia del progresso
    bar_format = '{l_bar}{bar:10}| {n:4}/{total_fmt}'\
                 ' [{elapsed:>7}<{remaining:>7}, {rate_fmt}{postfix}]'
    progression_bar = trange(n_episodes, unit="ep", bar_format=bar_format, ascii=True)

    for episode_index in progression_bar:
        game.newGame()
        state = np.array(game.getDiceValues() + [game.rollLeft()] + game.completed_rows, dtype=np.float32)
        episode_score = 0.0

        for _ in range(max_steps):
            valid_actions = get_valid_actions(game)
            if not valid_actions:
                print("Nessuna azione valida disponibile.")
                break

            action = agent.getAction(state, epsilon, valid_actions)  # Scelta dell'azione (con epsilon decay)
            game.chooseAction(action)
            reward = float(game.getLastReward())
            next_state = np.array(game.getDiceValues() + [game.rollLeft()] + game.completed_rows, dtype=np.float32)

            agent.save2Memory(state, action, reward, next_state, game.hasFinished())
            state = next_state
            episode_score += reward

            if game.hasFinished():
                break

        score_history.append(episode_score)
        epsilon = max(eps_end, epsilon * eps_decay)  # Decadimento di epsilon

        # Aggiorna la barra di avanzamento con il punteggio dell'episodio e il punteggio medio
        average_score = np.mean(score_history[-100:])
        progression_bar.set_postfix_str(
            f"Score: {episode_score: 7.2f}, 100 avg: {average_score: 7.2f}"
        )
        progression_bar.update(1)

        # Condizione di fermata se il punteggio medio raggiunge l'obiettivo
        if len(score_history) >= 100 and np.mean(score_history[-100:]) >= target_score:
            print("\nObiettivo raggiunto. Termino l'addestramento.")
            break

        # Salvataggio del modello durante l'addestramento
        if store_checkpoint and (episode_index + 1) % 10 == 0:
            torch.save(agent.net_eval.state_dict(), 'checkpoint_yahtzee_alt.pth')

    return score_history